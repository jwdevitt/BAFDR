# BAFDR
Full end to end radiometry calculators

The BAFDR software is a compilation of the modules from the Photonics Project radiometry calculators.  They are Blackbody, Atmosphere, Flux, Detector, and ReadOut.  The NETD and NIE calculation are also done although that does not appear in the pronounceable acronym name. The BAFDR_S will run a single end to end case the same as the online modules, but without user intervention.  BAFDR_M is multi-case.

The full ReadMe file is a text document that you can download from the repository.
